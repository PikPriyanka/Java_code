import java.util.*; 

public class Collection6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="JAVAJAVA";
		String s2="VA";
		int size1= s1.length();
		int size2= s2.length();
		String s="";
		ArrayList<String> ans = new ArrayList<String>(2100);
		char c;
		int j,k;
		
		//--------------Part 1 Starts--------------		
		for(int i=0; i<size1; i++){
		    c = s1.charAt(i);
		    if (i%2 == 1) {
		        s += c;
		     } else {
		        s += s2; 
		     }
		}
		ans.add(s);
		//---------------Part 1 Ends---------------
		
		
		//---------------------------Part 2 & 3 Starts ----------------------------
		int count=0;
		for(int i=0; i<=size1-size2; i++){
			j=i;
			k=0;
			while(k<size2 && s1.charAt(j++)==s2.charAt(k++));
			if(k==size2)
				count++;
		}
		if(count>1)
		{
			//--------------Part 2 Starts--------------
			StringBuilder sb1 = new StringBuilder(s1);
			StringBuilder sb2 = new StringBuilder(s2);
			for(int i=size1-size2; i>=0; i--){
				j=i;
				k=0;
				while(k<size2 && s1.charAt(j++)==s2.charAt(k++));
				if(k==size2)
				{
					sb1.replace(j-size2,j,sb2.reverse().toString());
					break;
				}
			}
			ans.add(sb1.toString());
			//--------------Part 2 Ends--------------
			
			//--------------Part 3--------------
			sb1 = new StringBuilder(s1);
			sb2 = new StringBuilder(s2);
			
				for(int i=0; i<=size1-size2; i++){
					j=i;
					k=0;
					while(k<size2 && s1.charAt(j++)==s2.charAt(k++));
					if(k==size2)
					{
						sb1.delete(j-size2,j);
						break;
					}
				}

			ans.add(sb1.toString());
			//--------------Part 3 Ends--------------
		}
		else
		{
			ans.add(s1+s2);
			ans.add(s1);
		}
		//---------------------------Part 2 & 3 Ends ---------------------------------
		
		
		//--------------Part 4 Starts--------------
		s=s2.substring(0, (size2+1)/2)+s1+s2.substring((size2+1)/2,size2);
		ans.add(s);
		//--------------Part 4 Ends--------------
		
		
		//--------------Part 5 Starts------------
		s=s1;
		for(int i=0; i<size2; i++)
			s=s.replace(s2.charAt(i), '*');
		ans.add(s);
		//--------------Part 5 Ends--------------
	System.out.println(ans);

	}
}
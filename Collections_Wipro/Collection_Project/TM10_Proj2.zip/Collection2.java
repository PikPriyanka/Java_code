import java.util.*;
import java.util.*;
public class Collection2{
	ArrayList<String> l = new ArrayList<String>();
	public static void main(String[] args){
	Collection2 c =  new Collection2();		
	Scanner sc = new Scanner(System.in);
	while(true){
		System.out.println("1. Insert");
		System.out.println("2. Search");
		System.out.println("3. Delete");
		System.out.println("4. Display");
		System.out.println("5. Exit");
		System.out.println("Enter your choice");
		int ch = sc.nextInt();
		int j =0;
			switch(ch){
				case 1: c.insert();
						break;
				case 2: c.search();
						break;
				case 3: c.delete();
						break;
				case 4: c.display();
						break;
				case 5: j=1;
						break;
				default: System.out.println("Wrong Choice");
			}
			if(j==1)
				break;
			}
	}
	public void insert(){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the item to be inserted:");
		String s = sc.next();
		l.add(s);
		System.out.println("Inserted successfully");
	}
	public void search(){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the item to search:");
		String s = sc.next();
		Iterator it = l.iterator();
		int i=0;
		while(it.hasNext())
		{
			if(((String)it.next()).equals(s)){
				System.out.println("Item found in the list");
				i=1;
			}
			
		}
		if(i==0)
			System.out.println("Item not found in the list");
	}
public void delete(){
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the item to delete:");
	String s = sc.next();
	boolean b = l.remove(s);
	if(b==true)
		System.out.println("Deleted Successfully");
	else
		System.out.println("Item does not exist");
}
public void display(){
	System.out.println("The Items in the list are:");
	for(String s : l)
		System.out.println(s);
}
}
